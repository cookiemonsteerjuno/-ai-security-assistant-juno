# Sentinel AI Android Edition (native Kotlin starter)

This is a native Kotlin Android project based on the uploaded Sentinel AI web project. It starts with real Android-supported, read-only device checks and explicit settings handoffs.

## Included in this first native build
- Manufacturer/model, Android version, build fingerprint, and OS security patch level.
- Active network transport and validated-internet status via `ConnectivityManager`.
- Wi-Fi transport status without harvesting SSID/BSSID.
- Bluetooth adapter state when the Android 12+ `BLUETOOTH_CONNECT` permission is granted.
- Sentinel's own declared permission status.
- Shortcuts to Android app permissions, privacy, security, Bluetooth, network, notification-access, and default-app settings.
- The original web project is preserved as `original-sentinel-web-project.zip`.

## Build without Android Studio
See `BUILD_WITHOUT_ANDROID_STUDIO.md`. A GitHub Actions workflow is included at `.github/workflows/build-apk.yml` to compile a debug APK in the cloud from a browser.

## Honest capability boundaries
An ordinary Android app cannot silently toggle Bluetooth, change GPS/location, inspect all packet traffic, read other apps' private data, install OS patches, or access call/SMS logs and SIM identifiers at will. Those require user-granted special roles, privileged/system signing, or are unavailable to third-party apps. The starter deliberately does not claim those protections are active. Notification access is only opened as a system settings screen; no listener is registered yet. No Gemini key is embedded.

## Build details
The project uses Android Gradle Plugin 8.9.2, Kotlin 2.1.10, compile SDK 35, and Java 17. The included GitHub workflow uses Gradle 8.11.1 and produces `app/build/outputs/apk/debug/app-debug.apk`.
