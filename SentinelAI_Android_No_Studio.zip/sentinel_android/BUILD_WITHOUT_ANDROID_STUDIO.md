# Build Sentinel AI without Android Studio (using GitHub Actions)

You can use a browser on your Motorola phone. This builds a debug APK in GitHub's cloud; it does not require Android Studio on your phone or computer.

1. Sign in to GitHub and create a **new private repository** (recommended because this project may contain your own work).
2. Extract this ZIP, open the `sentinel_android` folder, and upload its contents to the repository's root. Include the `.github/workflows/build-apk.yml` file and all hidden files/folders.
3. In the repository, open **Actions**. If prompted, enable Actions.
4. Select **Build Sentinel AI APK** on the left, tap **Run workflow**, then **Run workflow** again.
5. Wait for the run to finish successfully. Open that run and scroll to **Artifacts**.
6. Download `SentinelAI-debug-apk`. GitHub downloads it as a ZIP. Extract it and locate `app-debug.apk`.
7. Open the APK on your Motorola. If Android asks, allow your browser or Files app to **Install unknown apps** for this one installation, then return and install. Only install the APK you built from your own repository.

Notes:
- The workflow creates a debug-signed APK suitable for testing, not Play Store release distribution.
- GitHub account sign-in and cloud Actions availability are required. Do not upload signing keys, passwords, or API secrets to the repository.
- This APK is a first native starter with read-only device checks and settings shortcuts, not a full antivirus or automatic protection suite.
