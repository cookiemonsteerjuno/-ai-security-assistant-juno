package com.sentinelai.android

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var root: LinearLayout
    private val cyan = 0xFF22D3EE.toInt()
    private val muted = 0xFF94A3B8.toInt()
    private val panel = 0xFF0F172A.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF020617.toInt()
        window.navigationBarColor = 0xFF020617.toInt()
        if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 41)
        }
        render()
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF020617.toInt()) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 28) }
        scroll.addView(root)
        setContentView(scroll)

        text("SENTINEL AI", 26f, 0xFFFFFFFF.toInt(), true)
        text("ANDROID SECURITY CENTER", 12f, cyan, true)
        text("Native device checks · Read-only by design", 13f, muted, false)
        gap(20)
        section("DEVICE INTEGRITY")
        card("Device", "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        card("Security patch level", Build.VERSION.SECURITY_PATCH.ifBlank { "Not reported by this Android build" })
        card("Build fingerprint", Build.FINGERPRINT)

        section("CONNECTIVITY")
        card("Network", networkSummary())
        card("Wi-Fi", wifiSummary())
        card("Bluetooth", bluetoothSummary())
        action("Open Internet & network settings") { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
        action("Open Bluetooth settings") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }

        section("PRIVACY & APP SECURITY")
        card("Sentinel permissions", permissionSummary())
        action("Review app permissions") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) }
        action("Open Android privacy dashboard") {
            try { startActivity(Intent("android.settings.PRIVACY_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        action("Open security & privacy settings") {
            try { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        section("CALLS, MESSAGES & SIM")
        card("Status", "Android restricts call logs, SMS, phone identifiers, and SIM details. Sentinel does not silently read these. Optional integrations require explicit system-granted roles or access.")
        action("Review notification access") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        action("Open default apps / role settings") { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }

        section("WHAT SENTINEL CAN AND CANNOT DO")
        card("Active in this build", "Reads Android build and security patch metadata; checks current network transport; checks Bluetooth state when permission is granted; shows Sentinel's own permission state; opens relevant Android settings.")
        card("Not enabled / not claimed", "No antivirus engine, packet inspection, SIM-swap detection, call/SMS interception, remote lock, location spoofing, or automatic OS patch installation. Android does not expose these powers to an ordinary app.")
        text("Sentinel reports only information Android actually exposes. A settings shortcut is not the same as changing a system setting.", 12f, muted, false)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) {
        root.addView(TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 3, 0, 5) })
    }
    private fun gap(dp: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, dp)) }
    private fun section(name: String) { gap(16); text(name, 13f, cyan, true) }
    private fun card(title: String, body: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); setBackgroundColor(panel) }
        box.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(0xFFFFFFFF.toInt()); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        box.addView(TextView(this).apply { text = body; textSize = 12f; setTextColor(muted); setPadding(0, 7, 0, 0) })
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }
    private fun action(label: String, run: () -> Unit) {
        root.addView(Button(this).apply { text = label; isAllCaps = false; setTextColor(0xFF020617.toInt()); setBackgroundColor(cyan); setOnClickListener { try { run() } catch (_: Exception) { Toast.makeText(context, "This setting is unavailable on this Android version.", Toast.LENGTH_SHORT).show() } } }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
    }
    private fun networkSummary(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "No active network reported"
        val kind = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN transport"
            else -> "Other / unknown transport"
        }
        return "$kind · Internet validated: ${caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)}"
    }
    @Suppress("DEPRECATION") private fun wifiSummary(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) "Connected over Wi-Fi. Android limits SSID/BSSID access; this app does not collect them." else "Not currently using Wi-Fi, or status unavailable"
    }
    private fun bluetoothSummary(): String {
        return try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null) "Bluetooth hardware not available" else if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) "Permission not granted; use Android Bluetooth settings" else if (adapter.isEnabled) "On" else "Off"
        } catch (_: SecurityException) { "Permission not granted; use Android Bluetooth settings" }
    }
    private fun permissionSummary(): String {
        val perms = arrayOf(Manifest.permission.ACCESS_NETWORK_STATE, Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.BLUETOOTH_CONNECT)
        return perms.joinToString("\n") { p -> "${p.substringAfterLast('.')} : ${if (ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED || (p == Manifest.permission.BLUETOOTH_CONNECT && Build.VERSION.SDK_INT < 31)) "granted" else "not granted"}" }
    }
}
